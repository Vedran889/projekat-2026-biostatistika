###############################################################

#   6. Preditctive analytics

###############################################################

# Read the data and observe its structure
library(foreign)
dataset <- read.spss(file.choose(), to.data.frame=TRUE, 
                     use.value.labels = FALSE)
str(dataset)

# Important notes on dataset coding procedure:
# InformedaboutCP is 0->not informed, 1->informed
# IntroductionofCP is 0->No, 1->Yes
# InformedAboutPositiveEffects is 0->not informed, 1->informed
# Gender 1-> male, 2->female
# ResidentofCZRecode 1->No, 2->Yes

# Install and call the needed packages
install.packages("MASS")
install.packages("corrplot")
install.packages("ggplot2")
library(MASS)
library(corrplot)
library(ggplot2)

###############################################################

#   Correlation & Linear Regression

###############################################################

# compute the correlation matrix
corr.matrix <- cor(dataset)
# one option for plotting correlations: using colors to represent 
# the extent of correlation
corrplot(corr.matrix,
         method = "number", 
         type = "upper", 
         diag =  FALSE, 
         number.cex=0.75, 
         tl.cex = 0.85)

# plot *WTP* against the response variable
p1 <- ggplot(data = dataset, 
             mapping = aes(x = WTP, y = MAP)) +geom_point(shape = 1)
p1

# build an lm model 
lm1 <- lm(MAP ~ WTP, 
          data = dataset)
# print the model summary
summary(lm1)

#Interpretation


# compute 95% confidence interval
confint(lm1, level = 0.95)

# create a test data frame containing only WTP variable and three 
# observations: 5, 10, 11 – you can choose any value you want
df.test <- data.frame(WTP=c(5,10,11))

# calculate the predictions with the fitted model over the test 
# data
predict(lm1, newdata = df.test)

# calculate the predictions with the fitted model over the test 
# data, including the confidence interval
predict(lm1, newdata = df.test, interval = "confidence")

# plot the data points and the regression line
ggplot(data = dataset, mapping = aes(x = WTP, y = MAP)) +
  geom_point(shape = 1) +
  geom_smooth(method = "lm")

# build an multiple lm model 
lm2 <- lm(MAP ~ WTP + dailykm, data = dataset)
summary(lm2)

# compute 95% confidence interval
confint(lm2, level = 0.95)

# create a test data frame containing only WTP variable 
# observations: 2, 4, 6 and dailykm observations 8, 10, 20 – you can 
# choose any value you want
df.test <- data.frame(WTP=c(2,4,6), dailykm=c(8,10,20))
# calculate the predictions with the fitted model over the test 
# data
predict(lm2, newdata = df.test)

###############################################################

#   Handling Missing Values

###############################################################

# see if there are missing values
install.packages("Amelia")
install.packages("mlbench")
library(Amelia)
library(mlbench)
missmap(dataset, col=c("blue", "red"), legend=FALSE)

# inspect the correlation
correlations <- cor(dataset)
corrplot(correlations, method="circle")
print(correlations)


###############################################################

#   Logistic Regression model

###############################################################


#logistics regression model
install.packages("ISLR")
library(ISLR)

#Important note: Logistic regression always models the probability of the event coded as 1!
# there are no class predictions herein, just learning how X affects the log-odds of Y=1!
glm.fit <- glm(InformedaboutCP ~ Gender + Age + IncomeRecode + ResidentofCZRecode, 
               data = dataset, 
               family = binomial)

summary(glm.fit)

# Interpretation of coefficients:
# Each coefficient represents the change in log-odds of Y = 1
# for a one-unit increase in the predictor, holding others constant.
#
# A positive coefficient increases the odds (and thus probability) of Y = 1.
# A negative coefficient decreases the odds of Y = 1, which equivalently
# increases the probability of Y = 0 (i.e., 1 - P(Y = 1)).
#
# Because the logit link is nonlinear, coefficients are symmetric in log-odds
# space but asymmetric in probability space.

coef(glm.fit)
exp(coef(glm.fit))

# Interpretation of logistic regression coefficients
#
# Logistic regression models the log-odds of the event Y = 1 (InformedaboutCP = 1).
# Coefficients (coef) are changes in log-odds; exp(coef) are odds ratios.
# Odds ratios > 1 increase the odds of Y = 1; odds ratios < 1 decrease the odds.
#
# -------------------------
# (Intercept)
# -------------------------
# coef = 1.7017  |  OR = 5.48
#
# Interpretation:
# When all predictors are equal to zero (baseline categories),
# the odds of being informed about CP are approximately 5.5 times
# higher than the odds of not being informed.
#
# The intercept establishes the baseline probability of Y = 1
# before accounting for any predictor effects.
#
# -------------------------
# Gender
# -------------------------
# coef = -0.7080  |  OR = 0.49
#
# Gender is coded as: 1 = Male, 2 = Female.
# The negative coefficient (-0.708) indicates that moving from Male to Female
# decreases the log-odds of being informed about CP.
#
# The odds ratio (exp(coef) ≈ 0.49) implies that females have about 51% lower odds
# of being informed about CP compared to males, holding other variables constant.
#
# Consequently, being female increases the probability of Y = 0
# (not being informed), since P(Y = 0) = 1 - P(Y = 1).

#
# -------------------------
# Age
# -------------------------
# coef = -0.2691  |  OR = 0.76
#
# Interpretation:
# For each increase in Age category, the odds of being informed about CP
# decrease by a factor of approximately 0.76.
#
# This represents a 24% reduction in the odds of Y = 1 per age category increase.
#
# Conclusion:
# Older respondents are less likely to be informed about CP,
# holding all other variables constant.
#
# -------------------------
# IncomeRecode
# -------------------------
# coef = 0.3001  |  OR = 1.35
#
# Interpretation:
# Each increase in income category multiplies the odds of being informed
# about CP by approximately 1.35.
#
# This corresponds to a 35% increase in the odds of Y = 1.
#
# Conclusion:
# Higher income levels are associated with a greater likelihood
# of being informed about CP.
#
# -------------------------
# ResidentofCZRecode
# -------------------------
# coef = -0.0283  |  OR = 0.97
#
# Interpretation:
# Being a resident of the CZ area slightly decreases the odds of being informed
# about CP by about 2.8%.
#
# The odds ratio is very close to 1, indicating a weak or negligible effect.
#
# Conclusion:
# Residency status has little to no substantive influence on whether
# respondents are informed about CP.
#
# -------------------------
# Important conceptual note:
# -------------------------
# Positive coefficients increase the probability of Y = 1.
# Negative coefficients decrease the probability of Y = 1,
#    which equivalently increases the probability of Y = 0 (1 - P(Y = 1)).
#
# Effects are symmetric in log-odds space but asymmetric in probability space,
# due to the nonlinear (logit) link function.



# The following probabilities are IN-SAMPLE estimates.
# They are used ONLY for interpretation of coefficients,
# NOT for evaluation of predictive performance.
glm.probs <- predict(glm.fit, type = "response")
glm.probs[1:10]


# Applying a decision threshold converts probabilities into class labels.
# This step is shown for demonstration purposes only.
# These are NOT valid predictive classifications.

glm.pred <- ifelse(glm.probs > 0.5, "1", "0")

table(Predicted = glm.pred,
      True = dataset$InformedaboutCP)

mean(glm.pred == dataset$InformedaboutCP)


# Is everything going as it should be, up to this point?

# NO!

# Important notes:
# 1. Logistic regression is not a classifier method by default, so any classification is hard-coded.
# 2. In order to deal with predictions we should follow the methodological rigout in the analysis
#   meaning that the steps should be in the following order:
#     Split data → train / test
#     Fit model on train
#     Predict on test
#     Build confusion matrix on test
#     Compute metrics from that matrix
#   which we will do with Decision Trees!



###############################################################

#   Decision Trees

###############################################################

# -------------------------------------------------------------
# 0) Packages (install once, load each session)
# -------------------------------------------------------------
# install.packages("caret")
# install.packages("rpart")
# install.packages("rpart.plot")
# install.packages("pROC")

library(caret)
library(rpart)
library(rpart.plot)
library(pROC)

set.seed(123)

# this line is crucial to ensure that the fitting model is recognising Y levels as given in dataset description.
dataset$IntroductionofCP <- factor(dataset$IntroductionofCP, levels = c(0, 1))

# (Optional sanity check) class balance
table(dataset$IntroductionofCP)
prop.table(table(dataset$IntroductionofCP))

# Define labels for positive class and negative class (used in ROC and probability column selection)
pos <- "1"
neg <- "0"


# -------------------------------------------------------------
# 1) Train/Test split 
# -------------------------------------------------------------
train.indices <- createDataPartition(dataset$IntroductionofCP, p = 0.80, list = FALSE)
train.data <- dataset[train.indices, ]
test.data  <- dataset[-train.indices, ]


# -------------------------------------------------------------
# 2) Fit the tree on TRAIN data
# -------------------------------------------------------------
tree1 <- rpart(
  IntroductionofCP ~ EmploymentRecode + IncomeRecode,
  data = train.data,
  method = "class"
)

# Results of the classification model (tree structure)
print(tree1)

# OPTIONAL but recommended: prune to reduce overfitting
# rpart stores a CP table from internal cross-validation (xerror).
# We prune to the cp with minimum xerror.

# What is pruning? It means trimming off the branches or leaves on the tree.
# Herein, it stands for preventing the tree from getting too complex and too spread.
# This is particularly important when trying to prevent the model from OVERFITTING!

# smaller cp → more splits allowed → bigger tree
# larger cp → fewer splits allowed → smaller tree

printcp(tree1)
best.cp <- tree1$cptable[which.min(tree1$cptable[, "xerror"]), "CP"] #you can decide just by quick glancing on the output
best.cp

# This creates a new tree object that is cut back to the size specified by best.cp
tree1.pruned <- prune(tree1, cp = best.cp)

# Choose which model you want to evaluate:
# - tree1        = unpruned (often overfits)
# - tree1.pruned = pruned (usually generalizes better)
tree_model <- tree1.pruned
# tree_model <- tree1


# -------------------------------------------------------------
# 3) Plot the chosen tree (pick ONE style to stay consistent)
# -------------------------------------------------------------
prp(tree_model, type = 1, extra = 1)

# other variations of the graph:
# prp(tree_model, type = 3, extra = 1)
# prp(tree_model, type = 2, extra = 2)


# -------------------------------------------------------------
# 4) Predict on TEST data (classes + probabilities)
# -------------------------------------------------------------
# Predicted classes 
tree1.pred <- predict(tree_model, 
                      newdata = test.data, 
                      type = "class")
head(tree1.pred)

# Predicted probabilities (soft scores). This is needed for ROC/AUC and probability metrics.
tree1.prob <- predict(tree_model, 
                      newdata = test.data, 
                      type = "prob")

# Probabilities of the positive class only ("1")
prob_pos <- tree1.prob[, pos]
head(prob_pos)


# -------------------------------------------------------------
# 5) ROC and AUC (threshold-free evaluation)
# -------------------------------------------------------------
# WHAT ROC/AUC TELLS YOU:
# - ROC curve: trade-off between Sensitivity (TPR) and False Positive Rate (FPR)
#   for ALL possible thresholds on prob_pos.
# - AUC: how well the model RANKS positives above negatives.
#   AUC = 0.5 ~ random; AUC closer to 1.0 ~ strong separation.
#
# IMPORTANT:
# ROC/AUC does NOT depend on the single threshold used by tree1.pred.
# That’s why you can have decent AUC but low recall at the default threshold!

roc_obj <- roc(
  response  = test.data$IntroductionofCP,
  predictor = prob_pos,
  levels    = c(neg, pos),
  direction = "<"
)

auc_val <- as.numeric(auc(roc_obj))
auc_val

plot(roc_obj, print.auc = TRUE)


# -------------------------------------------------------------
# 6) OPTIONAL: Map ROC -> confusion-matrix metrics via a chosen threshold
# -------------------------------------------------------------
# If your AUC is decent but recall is low, you often need a different threshold.
# Example: Youden threshold maximizes (sensitivity + specificity - 1).
best <- coords(roc_obj, x = "best", best.method = "youden", transpose = FALSE)
thr_youden <- as.numeric(best["threshold"])
thr_youden

# Build a new set of predictions using that threshold
tree1.pred.youden <- ifelse(prob_pos >= thr_youden, 1, 0)
tree1.pred.youden <- factor(tree1.pred.youden, levels = c(0, 1))

# Confusion matrix with ROC-chosen threshold (same formation style as our main one)
tree1.cm.youden <- table(true=test.data$IntroductionofCP, predicted=tree1.pred.youden)
tree1.cm.youden


# -------------------------------------------------------------
# 7) Confusion matrix + metrics (your teaching block unchanged)
# -------------------------------------------------------------
# Confusion matrix
tree1.cm <- table(true=test.data$IntroductionofCP,
                  predicted=tree1.pred)
tree1.cm

# Beware that this confusion matrix is adjusted to this dataset where,
# IntroductionofCP is 0->No, 1->Yes.
# When we set confusion matrix with a goal of 1 being the positive class, the matrix is
#       predicted
# true  0  1
#   0   TN FP
#   1   FN TP
#
# Typically, the matrix is sorted differently, but this case is to show how it can be adjusted to current conditions of the variables encoded.


# function for computing evaluation matrix
compute.eval.metrics <- function(cmatrix) {
  TP <- cmatrix[2,2] # true positive
  TN <- cmatrix[1,1] # true negative
  FN <- cmatrix[2,1] # false negative
  FP <- cmatrix[1,2] # false positive
  acc <- sum(diag(cmatrix)) / sum(cmatrix)
  precision <- TP / (TP + FP)
  recall <- TP / (TP + FN)
  F1 <- 2*precision*recall / (precision + recall)
  c(accuracy = acc, precision = precision, recall = recall, F1 = F1)
}

# Metrics at the DEFAULT tree classification rule (tree1.pred)
tree1.eval <- compute.eval.metrics(tree1.cm)
tree1.eval

# Metrics at the ROC-based threshold (Youden), to compare against default
tree1.eval.youden <- compute.eval.metrics(tree1.cm.youden)
tree1.eval.youden



# -------------------------------------------------------------
# 8) OPTIONAL: Evaluate tree2 the SAME way 
# -------------------------------------------------------------
tree2 <- rpart(IntroductionofCP ~ ., data = train.data, method = "class")
tree2.prob <- predict(tree2, newdata = test.data, type = "prob")[, pos]
tree2.pred <- predict(tree2, newdata = test.data, type = "class")
tree2.cm   <- table(true=test.data$IntroductionofCP, predicted=tree2.pred)
tree2.eval <- compute.eval.metrics(tree2.cm)
roc2 <- roc(test.data$IntroductionofCP, 
            tree2.prob, 
            levels=c(neg,pos), 
            direction="<")
c(AUC_tree1 = auc_val, AUC_tree2 = as.numeric(auc(roc2)))
tree2.eval

# So, which model is performing better? Any guesses why is that happening?

# What can we do to find a better solution? :)

# Also, how can we use sensitivity and specificity in terms of expanding eval. metrics? :))



###############################################################

#   Knn & Cross-validation

###############################################################


# create train and test sets
set.seed(1010)
train.indices <- createDataPartition(dataset$IntroductionofCP, p = 
                                       .80, list = FALSE)
train.data <- dataset[train.indices,]
test.data <- dataset[-train.indices,]

#knn
install.packages("class")
library(class)
# create a knn model with k=5
knn.pred <- knn(train = train.data[,-12],
                test = test.data[,-12],
                cl = train.data$IntroductionofCP,
                k = 5) # 5 is chosen here just as a random guess

# print several predictions
head(knn.pred)
# create the confusion matrix
knn.cm <- table(true = test.data$IntroductionofCP, predicted = 
                  knn.pred)
knn.cm
# compute the evaluation metrics

# Beware that confusion matrix was previously built for specific context!
# Considering this situation, does it need any changes? Why?
knn.eval <- compute.eval.metrics(knn.cm)
knn.eval

# load e1071 library
library(e1071)
# define cross-validation (cv) parameters; we'll perform 10-fold 
# cross-validation
numFolds = trainControl( method = "cv", number = 10)
# define the range for k values to examine in the cross-validation
cpGrid = expand.grid(.k = seq(from=3, to = 25, by = 1))
# Set the seed
set.seed(1010)
# run the cross-validation
knn.cv <- train(IntroductionofCP ~ .,
                data = train.data,
                method = "knn",
                trControl = numFolds,
                tuneGrid = cpGrid)
knn.cv

# plot the cross-validation results
plot(knn.cv)
