############################################################
# Clustering 
# Source: "Clustering bez BiClu.pdf"

#   foreign  : import SPSS .sav data
#   cluster  : k-means helpers, PAM, CLARA, agnes/diana, silhouette
#   fpc      : pamk (auto-k), clusplot, clusterboot (stability)
#   NbClust  : 30+ indices to choose number of clusters
#   ggplot2  : simple scatter by cluster (Q3 visual)
############################################################

# ---- Install & load ---------------------------------------------------------
pkgs <- c("foreign","cluster","fpc","NbClust","ggplot2")
new <- pkgs[!(pkgs %in% installed.packages()[,"Package"])]
if (length(new)) install.packages(new)

library(foreign)
library(cluster)
library(fpc)
library(NbClust)
library(ggplot2)

# ---- Load main data (BRICS universities in slides) --------------------------
# Slide: read .sav then drop the name column "University".
dataset  <- read.spss(file.choose(), to.data.frame = TRUE)   # select bricsfull.sav
data.use <- subset(dataset, select = -c(University))         # numeric features only
# Output: data.use is the matrix used in all clustering below.  

# ============================================================================#
# K-means clustering (retain 4 clusters in slides)                            #
# ============================================================================#
kmeanscluster <- kmeans(data.use, 4)
table(kmeanscluster$cluster)   # Decision: counts per cluster show sample allocation.  
kmeanscluster$centers          # Decision: inspect centroids to profile clusters.       

# 2D cluster plot (slide example)
clusplot(data.use, kmeanscluster$cluster, color=TRUE, shade=TRUE, labels=2,
         lines=0, main="Cluster plot")  # Decision: ellipses and overlap for separation. 

# ============================================================================#
# K-medoids (PAM): retain 4 clusters                                          #
# ============================================================================#
pamcluster <- pam(data.use, 4, metric = "euclidean")
summary(pamcluster)                     # Decision: basic cluster quality summary.       
table(pamcluster$clustering)            # Decision: cluster sizes (balance).             
pamcluster$id.med                       # Decision: medoid IDs (representatives).        
dataset$University[pamcluster$id.med]   # Medoids by name.                                
dataset$University[pamcluster$clustering == 1]  # Names in cluster 1 (example).          
plot(pamcluster, main="Cluster plot of pam()")  # Cluster plot + silhouette.           

# ============================================================================#
# K-medoids with pamk() — automatic choice of k                               #
# ============================================================================#
pamk.result <- pamk(data.use)           # No k specified (auto)                          
pamk.result$nc                          # Decision: retained k by pamk().                

table(pamk.result$pamobject$clustering, pamcluster$clustering)  # Cross-tab clusters.   
plot(pamk.result$pamobject, main="Cluster plot of pamk()")      # Visual check.         

# ============================================================================#
# CLARA (for large n): ARWU 2016, k=5                                         #
# ============================================================================#
arwu.data <- read.spss(file.choose(), to.data.frame = TRUE)    # select "ARWU 2016.sav"
arwu.use  <- subset(arwu.data, select = -c(Institution))
clarax    <- clara(arwu.use, 5, samples = 150, sampsize = 100)
clarax                               # Decision: medoids, sizes, best sample.            
arwu.data$Institution[clarax$cluster == 1]   # Names in cluster 1 (example).             
arwu.data$Institution[clarax$i.med]          # Medoid institutions.                       
plot(clarax, main="Silhouette plot of clara() for 5 retained clusters")  # Silhouette.   
plot(arwu.use, col = clarax$cluster)  # Pairwise scatter by CLARA clusters.              

# ============================================================================#
# Hierarchical clustering (agglomerative, divisive; Ward/complete/single/avg) #
# ============================================================================#
d  <- dist(data.use, method = "euclidean")
hc <- hclust(d, method = "ward");     plot(hc)                    # Dendrogram.         
hc <- hclust(d, method = "complete"); plot(hc)                    # Compare linkage.    
hc <- hclust(d, method = "single");   plot(hc)                    # Compare linkage.    
hc <- hclust(d, method = "average");  plot(hc)                    # Compare linkage.    

# Cut tree and outline clusters on dendrogram (k = 3 as shown)
hc <- hclust(d, method = "ward")
clusters <- cutree(hc, k = 3)
rect.hclust(hc, k = 3, border = "black")  # Visual group borders.                         
table(clusters)                            # Decision: cluster sizes.                      
aggregate(data.use, list(clusters), mean)  # Decision: mean profiles per cluster.         
# (To view names in a given cluster:)
dataset$University[clusters == 1]          # Entities in cluster 1 (example).             

# Agglomerative vs divisive (agnes vs diana) with k=3 and cross-tab
agglomerative <- hclust(d, method = "ward")
agnesclus     <- cutree(agglomerative, k = 3)
divisive      <- diana(d)
divisclus     <- cutree(divisive, k = 3)
table(agnesclus, divisclus)  # Decision: agreement between agglomerative & divisive.     

# ============================================================================#
# Silhouette diagnostics                                                      #
# ============================================================================#
# Silhouette for PAM
sil <- silhouette(pamcluster$cluster, d)
plot(sil, cex.names = 0.6, nmax = 100,
     main = "Silhouette Plot of pam() clustering")
# Decision: sil ~1 well-clustered, ~0 border, <0 possible misfit.                         

# Silhouette for pamk()
sil <- silhouette(pamk.result$pamobject$cluster, d)
plot(sil, cex.names = 0.6, nmax = 100,
     main = "Silhouette Plot of pamk() clustering")  # Same interpretation.               

# Average silhouette width across k = 2..8 (PAM)
asw <- numeric(8)
for (k in 2:8) asw[k] <- pam(data.use, k)$silinfo$avg.width
k.best <- which.max(asw); asw; k.best
plot(1:8, asw, type = "l", main = "Best number of retained clusters",
     xlab = "Number of clusters", ylab = "Average silhouette width")
axis(1, k.best, paste("Best", k.best, sep = "\n"), col = "black", col.axis = "red")
# Decision: choose k with max ASW (≥0.51 reasonable; ≥0.71 strong).                       

# ============================================================================#
# K-means "elbow": average total within-cluster SS across many starts         #
# ============================================================================#
range <- 2:10
tries <- 100
avg.totw.ss <- integer(length(range))
for (v in range) {
  v.totw.ss <- integer(tries)
  for (i in 1:tries) {
    k.temp <- kmeans(data.use, centers = v)
    v.totw.ss[i] <- k.temp$tot.withinss
  }
  avg.totw.ss[v - 1] <- mean(v.totw.ss)
}
plot(range, avg.totw.ss, type = "b",
     main = "Total Within SS for various number of retained clusters",
     ylab = "Average Total Within Sum of Squares",
     xlab = "Number of retained clusters")
# Decision: look for the sharp bend (elbow) → suggested k.                                 

# ============================================================================#
# NbClust: 30+ indices to propose k (majority rule)                           #
# ============================================================================#
indices <- NbClust(data = data.use, diss = NULL, distance = "euclidean",
                   min.nc = 2, max.nc = 15, method = "kmeans",
                   index = "all", alphaBeale = 0.1)
indices$Best.nc        # Decision: how many clusters each index suggests + overall.       
indices$All.index      # Full table of index values across k.                              
indices$Best.partition # Best partition vector for chosen k.                               
dataset$University[indices$Best.partition == 1]  # Names within cluster 1 (example).       
# Decision: adopt the k supported by the majority of indices.                              

# ============================================================================#
# Cluster stability via resampling (clusterboot, Jaccard)                      #
# ============================================================================#
km.boot <- clusterboot(data.use, B = 20, bootmethod = "boot",
                       clustermethod = kmeansCBI, krange = 3, seed = 15555)
km.boot$result      # Decision: cluster sizes, means, SS by cluster.                       
km.boot$bootresult  # Decision: Jaccard per cluster (≈ stability; higher is better).       
plot(km.boot)       # Decision: histogram of Jaccard indices by cluster.                   

# ============================================================================#
# Simple graphical displays by cluster (Q3)                                   #
# ============================================================================#
# Base scatter, colored by pamk clusters (Academic vs Employer Reputation)
plot(dataset$AcademicReputation, dataset$EmployerReputation, type = "n",
     xlab = "Academic Reputation", ylab = "Employer Reputation",
     main = "Values per pamk() retained cluster")
text(x = dataset$AcademicReputation, y = dataset$EmployerReputation,
     col = pamk.result$pamobject$cluster + 1)
# Decision: visible separation/clumping supports the chosen clustering.                    

# ggplot2 example: AcademicRep vs StaffwithPhD by PAM(4) clusters
pamcluster$cluster <- as.factor(pamcluster$cluster)
graph <- ggplot(dataset, aes(AcademicReputation, StaffwithPhD,
                             color = pamcluster$cluster)) + geom_point()
plot(graph)
graph + labs(title = "Academic Reputation and Staff with PhD per cluster",
             x = "Academic Reputation", y = "Staff with PhD", color = "Cluster")
# Decision: quick visual profiling of clusters on two variables.                           
